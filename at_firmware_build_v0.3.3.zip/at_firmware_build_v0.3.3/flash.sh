#!/bin/sh

for file in $(ls /dev/tty.*); do
    echo "${file}"
done

echo "\n**************************\n"

echo "select port:\n tty.SLAB_USBtoUART=1\n tty.usbserial-14540=2\n tty.usbserial-14340=3\n tty.usbserial-14240=4\n tty.usbserial-14320=5"
my_port=""
read type
if [ ${type} == "1" ]; then
  my_port="tty.SLAB_USBtoUART"
elif [[ ${type} == "2" ]]; then
  my_port="tty.usbserial-14540"
elif [[ ${type} == "3" ]]; then
  my_port="tty.usbserial-14340"
elif [[ ${type} == "4" ]]; then
  my_port="tty.usbserial-14240"
elif [[ ${type} == "5" ]]; then
    my_port="tty.usbserial-14320"
else
  my_port="tty.SLAB_USBtoUART"
fi

echo "\n**************************\n"

echo "erase_flash?: YES:NO=1:0\n"
read flash
if [ ${flash} == "1" ]; then
    esptool.py --port /dev/${my_port} erase_flash
fi

python2 $IDF_PATH/components/esptool_py/esptool/esptool.py --chip esp8266 --port /dev/${my_port} --baud 115200 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 40m --flash_size 2MB 0xd000 ota_data_initial.bin 0x0000 bootloader.bin 0x10000 wf_at_firmware.bin 0x8000 partitions_two_ota.bin
